{
    "data": [
        {
            "id": "1",
            "recipients": [
                {
                    "id": "1",
                    "name": "Sagar Choudhary",
                    "email": "sc40421@gmail.com",
                    "profile_img": "300-19.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                }
            ],
            "recipients_cc": [
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_bcc": [
                {
                    "id": "1",
                    "name": "Nishant Sharma",
                    "email": "ns7632713@gmail.com",
                    "profile_img": "300-12.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                }
            ],
            "subject": "Your Order #224820998666029 has been Confirmed",
            "description": "Test Message",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "sent",
            "is_delete": "0"
        },
        {
            "id": "2",
            "recipients": [
                {
                    "id": "1",
                    "name": "Aakash Sharma",
                    "email": "ns7632713@gmail.com",
                    "profile_img": "300-12.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                },
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_cc": [
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_bcc": [
                {
                    "id": "1",
                    "name": "Nishant Sharma",
                    "email": "ns7632713@gmail.com",
                    "profile_img": "300-12.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                }
            ],
            "subject": "Your Order #224820998666029 has been Confirmed",
            "description": "Test Message",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "sent",
            "is_delete": "0"
        },
        {
            "id": "3",
            "recipients": [
                {
                    "id": "1",
                    "name": "Nishant Kumar",
                    "email": "ns7632713@gmail.com",
                    "profile_img": "300-15.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                },
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_cc": [
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_bcc": [
                {
                    "id": "1",
                    "name": "Nishant Sharma",
                    "email": "ns7632713@gmail.com",
                    "profile_img": "300-12.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                }
            ],
            "subject": "Your Order #5345773 has been Declined",
            "description": "Test Message",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "sent",
            "is_delete": "0"
        },
        {
            "id": "4",
            "recipients": [
                {
                    "id": "1",
                    "name": "Prashant Sah",
                    "email": "rg7562356424@gmail.com",
                    "profile_img": "300-17.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                },
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_cc": [
                {
                    "id": "3",
                    "name": "Lakshay Kaushik",
                    "email": "lakshay62374623@gmail.com",
                    "profile_img": "300-8.jpg"
                },
                {
                    "id": "4",
                    "name": "Kapil Sharma",
                    "email": "ksharma8748234@gmail.com",
                    "profile_img": "300-9.jpg"
                }
            ],
            "recipients_bcc": [
                {
                    "id": "1",
                    "name": "Nishant Sharma",
                    "email": "ns7632713@gmail.com",
                    "profile_img": "300-12.jpg"
                },
                {
                    "id": "2",
                    "name": "Ravinder Choudhary",
                    "email": "rc4123723@gmail.com",
                    "profile_img": "300-7.jpg"
                }
            ],
            "subject": "Your Order #224820998666029 has been Confirmed",
            "description": "Test Message",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "sent",
            "is_delete": "0"
        }
    ]
}
