{
    "data": [
        {
            "id": "1",
            "name": "Indian Rupee",
            "currency": "INR",
            "symbol": "&#x20B9;",
            "description": "",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "active",
            "ip_address": "49.36.200.34",
            "is_delete": "0",
            "country" : {
                "id" : "1",
                "name" : "India",
                "img" : "india.svg"
            }
            
        },
        {
            "id": "2",
            "name": "Dollar",
            "currency": "USD",
            "symbol": "&#36;",
            "description": "",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "active",
            "ip_address": "49.36.200.34",
            "is_delete": "0",
            "country" : {
                "id" : "5",
                "name" : "Australia",
                "img" : "australia.svg"
            }
        }
    ]
}
