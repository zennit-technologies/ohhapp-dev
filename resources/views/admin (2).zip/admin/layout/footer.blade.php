<div class="app-footer align-items-center justify-content-between">
    <!--begin::Copyright-->
    <div class="text-dark order-2 order-md-1">
        <span class="text-muted fw-bold me-1">2022 ©</span>
        <a href="https://oohap.com" target="_blank" class="text-gray-800 text-hover-primary">OOHAP</a>
    </div>
    <!--end::Copyright-->
    <!--begin::Menu-->
    <ul class="menu menu-gray-600 menu-hover-primary fw-bold order-1">
        <li class="menu-item">
            <a href="https://oohap.com" target="_blank" class="menu-link px-2">About</a>
        </li>
        <li class="menu-item">
            <a href="https://oohap.com" target="_blank" class="menu-link px-2">Support</a>
        </li>
        <li class="menu-item">
            <a href="https://oohap/EA4JP" target="_blank" class="menu-link px-2">Purchase</a>
        </li>
    </ul>
    <!--end::Menu-->
</div>
