{
    "data": [
        {
            "id": "1",
            "name": "Bulletin",
            "img": "bulletin.png",
            "description": "Description Bulletin",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "active",
            "is_delete": "0"
        },
        {
            "id": "1",
            "name": "Digital Billboards",
            "img": "digital_billboard.png",
            "description": "Test Description",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "19 Sep 2022, 6:43 am",
            "status": "active",
            "is_delete": "0"
        }
    ]
}
