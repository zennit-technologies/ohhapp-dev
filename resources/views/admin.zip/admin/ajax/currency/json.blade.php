{
    "data": [
        {
            "id": "1",
            "name": "Indian Rupee",
            "currency": "INR",
            "symbol": "&#x20B9;",
            "description": "",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "active",
            "ip_address": "49.36.200.34",
            "is_delete": "0",
            "countries" : [
                {
                    "id" : "1",
                    "name" : "India",
                    "img" : "india.svg"
                },{
                    "id" : "2",
                    "name" : "Afghanistan",
                    "img" : "afghanistan.svg"
                },{
                    "id" : "3",
                    "name" : "Albania",
                    "img" : "albania.svg"
                },{
                    "id" : "4",
                    "name" : "Algeria",
                    "img" : "algeria.svg"
                },
                {
                    "id" : "5",
                    "name" : "Australia",
                    "img" : "australia.svg"
                },{
                    "id" : "6",
                    "name" : "Andorra",
                    "img" : "andorra.svg"
                },{
                    "id" : "7",
                    "name" : "Iraq",
                    "img" : "iraq.svg"
                },{
                    "id" : "9",
                    "name" : "Kuwait",
                    "img" : "kuwait.svg"
                }
            ]
        },
        {
            "id": "2",
            "name": "Dollar",
            "currency": "USD",
            "symbol": "&#36;",
            "description": "",
            "updated_at": "22 Sep 2022, 6:43 am",
            "created_at": "18 Sep 2022, 6:43 am",
            "status": "active",
            "ip_address": "49.36.200.34",
            "is_delete": "0",
            "countries" : [
                {
                    "id" : "1",
                    "name" : "India",
                    "img" : "india.svg"
                },{
                    "id" : "2",
                    "name" : "Afghanistan",
                    "img" : "afghanistan.svg"
                },{
                    "id" : "3",
                    "name" : "Albania",
                    "img" : "albania.svg"
                },{
                    "id" : "4",
                    "name" : "Algeria",
                    "img" : "algeria.svg"
                },
                {
                    "id" : "5",
                    "name" : "Australia",
                    "img" : "australia.svg"
                },{
                    "id" : "6",
                    "name" : "Andorra",
                    "img" : "andorra.svg"
                },{
                    "id" : "7",
                    "name" : "Iraq",
                    "img" : "iraq.svg"
                },{
                    "id" : "9",
                    "name" : "Kuwait",
                    "img" : "kuwait.svg"
                }
            ]
        }
    ]
}
